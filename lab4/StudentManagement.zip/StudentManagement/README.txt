STUDENT INFORMATION:
Name: Mai Long Thiên
Student ID: ITCSIU23059
Class: ITIT23UN41

COMPLETED EXERCISES:
[x] Exercise 5: Search Functionality
[x] Exercise 6: Validation Enhancement
[x] Exercise 7: Pagination
[ ] Bonus 1: CSV Export
[ ] Bonus 2: Sortable Columns

KNOWN ISSUES:
- Finished exercises but did not implement bonus features.

EXTRA FEATURES:
- None

TIME SPENT: 3 hours

REFERENCES USED:
- https://www.tutorialspoint.com/jsp/jsp_database_access.htm
- https://www.w3schools.com/java/java_regex.asp
- https://www.w3schools.com/jsref/met_win_settimeout.asp