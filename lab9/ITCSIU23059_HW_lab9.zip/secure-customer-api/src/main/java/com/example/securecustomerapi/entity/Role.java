package com.example.securecustomerapi.entity;

public enum Role {
    USER,
    ADMIN
}
