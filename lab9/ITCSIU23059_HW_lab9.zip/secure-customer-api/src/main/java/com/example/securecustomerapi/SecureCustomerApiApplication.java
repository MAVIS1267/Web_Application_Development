package com.example.securecustomerapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecureCustomerApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(SecureCustomerApiApplication.class, args);
    }

}
