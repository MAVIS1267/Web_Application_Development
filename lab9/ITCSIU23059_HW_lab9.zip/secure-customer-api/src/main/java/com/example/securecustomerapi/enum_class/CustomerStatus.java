package com.example.securecustomerapi.enum_class;

public enum CustomerStatus {
    ACTIVE,
    INACTIVE
}
