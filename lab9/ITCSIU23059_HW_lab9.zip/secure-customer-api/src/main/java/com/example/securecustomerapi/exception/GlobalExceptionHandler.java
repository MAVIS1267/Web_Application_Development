package com.example.securecustomerapi.exception;

public class GlobalExceptionHandler {
}
