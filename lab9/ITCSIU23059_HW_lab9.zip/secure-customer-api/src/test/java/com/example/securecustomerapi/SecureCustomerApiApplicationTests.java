package com.example.securecustomerapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecureCustomerApiApplicationTests {

    @org.springframework.beans.factory.annotation.Autowired
    private com.example.securecustomerapi.repository.UserRepository userRepository;

}
