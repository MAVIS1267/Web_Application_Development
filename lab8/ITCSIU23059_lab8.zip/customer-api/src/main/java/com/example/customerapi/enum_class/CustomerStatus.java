package com.example.customerapi.enum_class;

public enum CustomerStatus {
    ACTIVE,
    INACTIVE
}
